<template>
  <div>
    <input type="text">
    <tbody>
      <tr>
        <td>1</td>
      </tr>
    </tbody>
  </div>
</template>
<script>
export default {
  data(){
    return{
      shuju:[]
    }
  },
  methods: {
    // 获取数据
    
  },
}
</script>